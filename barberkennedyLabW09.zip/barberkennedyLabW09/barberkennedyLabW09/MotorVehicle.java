package barberkennedyLabW09;

/**
 * MotorVehicle (middle level) — abstract (can't instantiate)
 */
public abstract class MotorVehicle extends Vehicle {
    protected int numWheels;

    public MotorVehicle() {
        super();
        this.numWheels = 4;
    }

    public MotorVehicle(String brand, String model, int year, double topSpeed, double horsepower, int numWheels) {
        super(brand, model, year, topSpeed, horsepower);
        this.numWheels = numWheels;
    }

    public int getNumWheels() { return numWheels; }
    public void setNumWheels(int numWheels) { this.numWheels = numWheels; }

    @Override
    public String toString() {
        return super.toString() + String.format(", Wheels: %d", numWheels);
    }
}
