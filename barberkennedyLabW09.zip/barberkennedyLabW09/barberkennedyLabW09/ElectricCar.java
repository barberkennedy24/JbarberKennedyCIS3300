package barberkennedyLabW09;

/**
 * ElectricCar extends Car (shows deeper hierarchy)
 */
public class ElectricCar extends Car {
    private double batteryKWh; // unique attribute

    public ElectricCar() {
        super();
        this.batteryKWh = 0.0;
    }

    public ElectricCar(String brand, String model, int year, double topSpeed, double horsepower, int numWheels, int numDoors, double batteryKWh) {
        super(brand, model, year, topSpeed, horsepower, numWheels, numDoors);
        this.batteryKWh = batteryKWh;
    }

    public double getBatteryKWh() { return batteryKWh; }
    public void setBatteryKWh(double batteryKWh) { this.batteryKWh = batteryKWh; }

    @Override
    public void drive() {
        System.out.println("The electric car glides silently using its battery.");
    }

    @Override
    public String toString() {
        return "ElectricCar: " + super.toString() + String.format(", Battery: %.1f kWh", batteryKWh);
    }
}
