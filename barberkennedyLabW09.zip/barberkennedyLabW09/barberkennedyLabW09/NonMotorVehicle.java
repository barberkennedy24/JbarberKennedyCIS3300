package barberkennedyLabW09;

/**
 * NonMotorVehicle (middle level) — abstract
 */
public abstract class NonMotorVehicle extends Vehicle {
    protected boolean humanPowered;

    public NonMotorVehicle() {
        super();
        this.humanPowered = true;
    }

    public NonMotorVehicle(String brand, String model, int year, double topSpeed, double horsepower, boolean humanPowered) {
        super(brand, model, year, topSpeed, horsepower);
        this.humanPowered = humanPowered;
    }

    public boolean isHumanPowered() { return humanPowered; }
    public void setHumanPowered(boolean humanPowered) { this.humanPowered = humanPowered; }

    @Override
    public String toString() {
        return super.toString() + String.format(", HumanPowered: %b", humanPowered);
    }
}
