package barberkennedyLabW09;

/**
 * Bicycle extends NonMotorVehicle
 */
public class Bicycle extends NonMotorVehicle {
    private int gearCount;

    public Bicycle() {
        super();
        this.gearCount = 1;
    }

    public Bicycle(String brand, String model, int year, double topSpeed, double horsepower, boolean humanPowered, int gearCount) {
        super(brand, model, year, topSpeed, horsepower, humanPowered);
        this.gearCount = gearCount;
    }

    public int getGearCount() { return gearCount; }
    public void setGearCount(int gearCount) { this.gearCount = gearCount; }

    @Override
    public void drive() {
        System.out.println("The bicycle is pedaled along the path.");
    }

    @Override
    public String toString() {
        return "Bicycle: " + super.toString() + String.format(", Gears: %d", gearCount);
    }
}
