package barberkennedyLabW09;

import java.io.*;
import java.util.*;

/**
 * Garage - stores Vehicle objects polymorphically
 */
public class Garage {
    private List<Vehicle> vehicles = new ArrayList<>();

    // add a new vehicle
    public void addVehicle(Vehicle v) {
        vehicles.add(v);
    }

    // display all vehicles (uses toString and drive polymorphically)
    public void displayAllVehicles() {
        if (vehicles.isEmpty()) {
            System.out.println("Garage is empty.");
            return;
        }
        for (Vehicle v : vehicles) {
            System.out.println(v.toString());
            v.drive();
            System.out.println("-----");
        }
    }

    // load vehicle data from a simple CSV file (see example format below)
    public void loadFromCSV(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int lineNo = 0;
            while ((line = br.readLine()) != null) {
                lineNo++;
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue; // skip blank or comment lines
                String[] parts = line.split(",");
                for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();

                String kind = parts[0].toLowerCase();
                try {
                    switch (kind) {
                        case "car": {
                            // expected: Car,brand,model,year,topSpeed,horsepower,numWheels,numDoors
                            if (parts.length < 8) throw new IllegalArgumentException("Wrong fields for Car");
                            Car c = new Car(parts[1], parts[2],
                                    Integer.parseInt(parts[3]),
                                    Double.parseDouble(parts[4]),
                                    Double.parseDouble(parts[5]),
                                    Integer.parseInt(parts[6]),
                                    Integer.parseInt(parts[7]));
                            addVehicle(c);
                            break;
                        }
                        case "electriccar": {
                            // ElectricCar,brand,model,year,topSpeed,horsepower,numWheels,numDoors,batteryKWh
                            if (parts.length < 9) throw new IllegalArgumentException("Wrong fields for ElectricCar");
                            ElectricCar e = new ElectricCar(parts[1], parts[2],
                                    Integer.parseInt(parts[3]),
                                    Double.parseDouble(parts[4]),
                                    Double.parseDouble(parts[5]),
                                    Integer.parseInt(parts[6]),
                                    Integer.parseInt(parts[7]),
                                    Double.parseDouble(parts[8]));
                            addVehicle(e);
                            break;
                        }
                        case "truck": {
                            // Truck,brand,model,year,topSpeed,horsepower,numWheels,cargoCapacity
                            if (parts.length < 8) throw new IllegalArgumentException("Wrong fields for Truck");
                            Truck t = new Truck(parts[1], parts[2],
                                    Integer.parseInt(parts[3]),
                                    Double.parseDouble(parts[4]),
                                    Double.parseDouble(parts[5]),
                                    Integer.parseInt(parts[6]),
                                    Double.parseDouble(parts[7]));
                            addVehicle(t);
                            break;
                        }
                        case "motorcycle": {
                            // Motorcycle,brand,model,year,topSpeed,horsepower,numWheels,hasSidecar
                            if (parts.length < 8) throw new IllegalArgumentException("Wrong fields for Motorcycle");
                            Motorcycle m = new Motorcycle(parts[1], parts[2],
                                    Integer.parseInt(parts[3]),
                                    Double.parseDouble(parts[4]),
                                    Double.parseDouble(parts[5]),
                                    Integer.parseInt(parts[6]),
                                    Boolean.parseBoolean(parts[7]));
                            addVehicle(m);
                            break;
                        }
                        case "bicycle": {
                            // Bicycle,brand,model,year,topSpeed,horsepower,humanPowered,gearCount
                            if (parts.length < 8) throw new IllegalArgumentException("Wrong fields for Bicycle");
                            Bicycle b = new Bicycle(parts[1], parts[2],
                                    Integer.parseInt(parts[3]),
                                    Double.parseDouble(parts[4]),
                                    Double.parseDouble(parts[5]),
                                    Boolean.parseBoolean(parts[6]),
                                    Integer.parseInt(parts[7]));
                            addVehicle(b);
                            break;
                        }
                        default:
                            System.err.printf("Unknown vehicle type on line %d: %s%n", lineNo, parts[0]);
                    }
                } catch (Exception ex) {
                    System.err.printf("Error parsing line %d: %s -> %s%n", lineNo, line, ex.getMessage());
                }
            }
        } catch (FileNotFoundException fnf) {
            System.err.println("CSV file not found: " + filename);
        } catch (IOException ioe) {
            System.err.println("Error reading CSV: " + ioe.getMessage());
        }
    }

    // remove all vehicles matching a given type name (class or superclass simple name)
    // e.g., removeByTypeName("ElectricCar") or removeByTypeName("MotorVehicle")
    public void removeByTypeName(String typeName) {
        if (typeName == null || typeName.isEmpty()) return;
        String want = typeName.trim().toLowerCase();
        Iterator<Vehicle> it = vehicles.iterator();
        while (it.hasNext()) {
            Vehicle v = it.next();
            if (matchesTypeName(v, want)) {
                it.remove();
            }
        }
    }

    // helper that checks class+superclasses simple names for a match
    private boolean matchesTypeName(Vehicle v, String wantLower) {
        Class<?> c = v.getClass();
        while (c != null) {
            if (c.getSimpleName().toLowerCase().equals(wantLower)) return true;
            c = c.getSuperclass();
        }
        return false;
    }
}
