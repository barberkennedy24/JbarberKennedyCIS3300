package barberkennedyLabW09;

public class GarageApp {
    public static void main(String[] args) {
        Garage garage = new Garage();

        // 1) manually add vehicles to demonstrate
        garage.addVehicle(new Car("Toyota", "Corolla", 2018, 120.0, 132.0, 4, 4));
        garage.addVehicle(new ElectricCar("Tesla", "Model 3", 2021, 150.0, 283.0, 4, 4, 75.0));
        garage.addVehicle(new Truck("Ford", "F-150", 2016, 110.0, 290.0, 4, 1200.0));
        garage.addVehicle(new Motorcycle("Yamaha", "MT-07", 2019, 140.0, 75.0, 2, false));
        garage.addVehicle(new Bicycle("Giant", "Escape 3", 2020, 30.0, 0.0, true, 21));

        System.out.println("=== Initial vehicles (manually added) ===");
        garage.displayAllVehicles();

        // 2) load from CSV (example file name: vehicles.csv)
        System.out.println("\n=== Loading vehicles from CSV ===");
        garage.loadFromCSV("vehicles.csv"); // put vehicles.csv in project root or supply full path
        garage.displayAllVehicles();

        // 3) demonstrate remove by type
        System.out.println("\n=== Removing all ElectricCar instances ===");
        garage.removeByTypeName("ElectricCar");
        garage.displayAllVehicles();

        System.out.println("\n=== Removing all MotorVehicle instances (will remove cars, trucks, motorcycles, etc.) ===");
        garage.removeByTypeName("MotorVehicle");
        garage.displayAllVehicles();
    }
}
