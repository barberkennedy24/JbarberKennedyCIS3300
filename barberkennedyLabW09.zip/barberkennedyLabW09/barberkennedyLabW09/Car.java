package barberkennedyLabW09;

/**
 * Car (concrete) extends MotorVehicle
 */
public class Car extends MotorVehicle {
    private int numDoors;

    public Car() {
        super();
        this.numDoors = 4;
    }

    public Car(String brand, String model, int year, double topSpeed, double horsepower, int numWheels, int numDoors) {
        super(brand, model, year, topSpeed, horsepower, numWheels);
        this.numDoors = numDoors;
    }

    public int getNumDoors() { return numDoors; }
    public void setNumDoors(int numDoors) { this.numDoors = numDoors; }

    @Override
    public void drive() {
        System.out.println("The car cruises down the road.");
    }

    @Override
    public String toString() {
        return "Car: " + super.toString() + String.format(", Doors: %d", numDoors);
    }
}
