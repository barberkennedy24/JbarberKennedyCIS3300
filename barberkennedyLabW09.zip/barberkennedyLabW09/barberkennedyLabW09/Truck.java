package barberkennedyLabW09;

/**
 * Truck extends MotorVehicle
 */
public class Truck extends MotorVehicle {
    private double cargoCapacity; // in pounds (unique attribute)

    public Truck() {
        super();
        this.cargoCapacity = 0.0;
    }

    public Truck(String brand, String model, int year, double topSpeed, double horsepower, int numWheels, double cargoCapacity) {
        super(brand, model, year, topSpeed, horsepower, numWheels);
        this.cargoCapacity = cargoCapacity;
    }

    public double getCargoCapacity() { return cargoCapacity; }
    public void setCargoCapacity(double cargoCapacity) { this.cargoCapacity = cargoCapacity; }

    @Override
    public void drive() {
        System.out.println("The truck hauls cargo with steadiness.");
    }

    @Override
    public String toString() {
        return "Truck: " + super.toString() + String.format(", CargoCapacity: %.1f", cargoCapacity);
    }
}
