package barberkennedyLabW09;

/**
 * Vehicle (abstract base class)
 * - cannot be instantiated directly
 */
public abstract class Vehicle {
    protected String brand;
    protected String model;
    protected int year;
    protected double topSpeed;
    protected double horsepower;

    // default constructor
    public Vehicle() {
        this("Unknown", "Unknown", 0, 0.0, 0.0);
    }

    // parameterized constructor
    public Vehicle(String brand, String model, int year, double topSpeed, double horsepower) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.topSpeed = topSpeed;
        this.horsepower = horsepower;
    }

    // getters & setters
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public double getTopSpeed() { return topSpeed; }
    public void setTopSpeed(double topSpeed) { this.topSpeed = topSpeed; }

    public double getHorsepower() { return horsepower; }
    public void setHorsepower(double horsepower) { this.horsepower = horsepower; }

    // generic drive method (can be overridden)
    public void drive() {
        System.out.println("The vehicle moves forward.");
    }

    @Override
    public String toString() {
        return String.format("%s %s (Year: %d, TopSpeed: %.1f, HP: %.1f)",
                brand, model, year, topSpeed, horsepower);
    }
}
