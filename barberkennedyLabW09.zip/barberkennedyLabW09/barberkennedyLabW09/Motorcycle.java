package barberkennedyLabW09;

/**
 * Motorcycle extends MotorVehicle
 */
public class Motorcycle extends MotorVehicle {
    private boolean hasSidecar;

    public Motorcycle() {
        super();
        this.hasSidecar = false;
    }

    public Motorcycle(String brand, String model, int year, double topSpeed, double horsepower, int numWheels, boolean hasSidecar) {
        super(brand, model, year, topSpeed, horsepower, numWheels);
        this.hasSidecar = hasSidecar;
    }

    public boolean hasSidecar() { return hasSidecar; }
    public void setHasSidecar(boolean hasSidecar) { this.hasSidecar = hasSidecar; }

    @Override
    public void drive() {
        System.out.println("The motorcycle zips through traffic.");
    }

    @Override
    public String toString() {
        return "Motorcycle: " + super.toString() + String.format(", Sidecar: %b", hasSidecar);
    }
}
